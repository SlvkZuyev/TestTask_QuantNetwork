package com.sldev.data.utils

const val API_BASE_URL = "https://api.unsplash.com/"
const val ROUTE_IMAGE_LIST = "photos"
const val AUTH_ID = "ab3411e4ac868c2646c0ed488dfd919ef612b04c264f3374c97fff98ed253dc9"
const val ROUTE_FULL_IMAGE = ""